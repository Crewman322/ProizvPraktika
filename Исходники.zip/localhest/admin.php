﻿<!DOCTYPE html>
<!--
 * A Design by GraphBerry
 * Author: GraphBerry
 * Author URL: http://graphberry.com
 * License: http://graphberry.com/pages/license
-->
<html lang="en">
    
    <head>
        <meta charset=utf-8>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Библиотека НАцСильИНК</title>
        <!-- Load Roboto font -->
        <link href='http://fonts.googleapis.com/css?family=Roboto:400,300,700&amp;subset=latin,latin-ext' rel='stylesheet' type='text/css'>
        <!-- Load css styles -->
        <link rel="stylesheet" type="text/css" href="css/bootstrap.css" />
        <link rel="stylesheet" type="text/css" href="css/bootstrap-responsive.css" />
        <link rel="stylesheet" type="text/css" href="css/style.css" />
        <link rel="stylesheet" type="text/css" href="css/pluton.css" />
        <!--[if IE 7]>
            <link rel="stylesheet" type="text/css" href="css/pluton-ie7.css" />
        <![endif]-->
        <link rel="stylesheet" type="text/css" href="css/jquery.cslider.css" />
        <link rel="stylesheet" type="text/css" href="css/jquery.bxslider.css" />
        <link rel="stylesheet" type="text/css" href="css/animate.css" />
        <!-- Fav and touch icons -->
        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/apple-touch-icon-72.png">
        <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57.png">
        <link rel="shortcut icon" href="images/ico/favicon.ico">
    </head>
    
    <body>
        <div class="navbar">
            <div class="navbar-inner">
                <div class="container">
                    <a href="#" class="brand">
                        <img src="images/logo.png" width="120" height="40" alt="Logo" />
                        <!-- This is website logo -->
                    </a>
                    <!-- Navigation button, visible on small resolution -->
                    <button type="button" class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
                        <i class="icon-menu"></i>
                    </button>
                    <!-- Main navigation -->
                    <div class="nav-collapse collapse pull-right">
                        <ul class="nav" id="top-navigation">
							<li class="active"><a href="drop.php">Завершение работы</a></li> 
                    </div>
                    <!-- End main navigation -->
                </div>
            </div>
        </div>

        </div>

    </header>
<style>
body {
background-color: #FFD700
}
TABLE {
    border: 4px solid #000;
	color: black;
   }
a {
    color: #008000; 
    text-decoration: none;
   }
a:visited {
    color: #000; 
   } 
a:hover {
    color: #000;
		} 
</style>

    <section class="box-with-image-right section-top-space">
    
        <div class="center">
			
            <div class="green-line">
            </div>
            <?
                include("dbinsert.php");
                $str = "SELECT vidacha.id, datevid, dateback,reader_id, books_id FROM vidacha";
                $result = mysqli_query($link, $str) or die("Не могу выполнить запрос1!");
            ?>
			<a href="proverki.php" type="button">Поиск задолженности</a></p>
                <h1><font color="black">Выдача</font></h1><a href="vidacha.php" type="button">Выдать книгу</a><p>
            
			 
                <table align="center" border="1">
                    <tr>
						<td>#</td>
                        <td>Дата выдачи</td>
                        <td>Дата возврата</td>
                        <td>Читатель</td>
                        <td>Книга</td>
                        <td>Удалить</td>
                    </tr>
                    <?
                        while($row=mysqli_fetch_array($result))
                    {?>
                    <tr>
						<td><?print $row["id"];?></td>
                        <td><?print $row["datevid"];?></td>
                        <td><?print $row["dateback"];?></td>
                        <td><?print $row["reader_id"];?></td>
                        <td><?print $row["books_id"];?></td>
                        <td><a href="admin.php?&vidachaid=<?print $row["id"];?>">Удалить</a></td>
                    </tr>
                    <?}?>
                </table>
                <?
                    $vidachaid = $_GET["vidachaid"];
                    if($vidachaid != "")
                    {
                        $str2 = "DELETE FROM `vidacha` WHERE `id` =".$vidachaid;
                        $result2 = mysqli_query($link, $str2) or die("Не могу выполнить запрос2!");
                    }
                ?>

                <?
                include("dbinsert.php");
                $str3 = "SELECT * FROM reader";
                $result3 = mysqli_query($link, $str3) or die("Не могу выполнить запрос1!");
                ?>
                <h1><font color="black">Читатели</font></h1><a href="reader.php" type="button">Добавить читателя</a>
                <table align="center" border="1">
                    <tr>
                        <td>№</td>
                        <td>Имя</td>
                        <td>Адрес</td>
                        <td>Номер</td>
                        <td>Изменить</td>
                        <td>Удалить</td>
                    </tr>
                    <?
                        while($row=mysqli_fetch_array($result3))
                    {?>
                    <tr>
                        <td><?print $row["id"];?></td>
                        <td><?print $row["fio"];?></td>
                        <td><?print $row["adress"];?></td>
                        <td><?print $row["phonenum"];?></td>
                        <td><a href="updatereader.php?&id=<?print $row["id"];?>">Изменить</a></td>
                        <td><a href="admin.php?&readerid=<?print $row["id"];?>">Удалить</a></td>
                    </tr>
                    <?}?>
                </table>
                <?
                    $readerid = $_GET["readerid"];
                    if($readerid != "")
                    {
                        $str4 = "DELETE FROM `reader` WHERE `id` =".$readerid;
                        $result4 = mysqli_query($link, $str4) or die("Не могу выполнить запрос2!");
                    }
                ?>

                <?
                include("dbinsert.php");
                $str5 = "SELECT * FROM books";
                $result5 = mysqli_query($link, $str5) or die("Не могу выполнить запрос1!");

                ?>
                <h1><font color="black">Книги</font></h1><a href="book.php" type="button">Добавить книгу</a>
                <table align="center" border="1">
                    <tr>
                        <td>#</td>
                        <td>Название</td>
						<td>Автор</td>
                        <td>Год издания</td>
						<td>Раздел</td>
                        <td>Изменить</td>
                        <td>Удалить</td>
                    </tr>
                    <?
                        while($row=mysqli_fetch_array($result5))
                    {?>
                    <tr>
                        <td><?print $row["id"];?></td>
                        <td><?print $row["name"];?></td>
						<td><?print $row["avtor_id"];?></td>
						<td><?print $row["godizda"];?></td>
                        <td><?print $row["hranitsa"];?></td>
                        <td><a href="updatebook.php?&id=<?print $row["id"];?>">Изменить</a></td>
                        <td><a href="admin.php?&bookid=<?print $row["id"];?>">Удалить</a></td>
                    </tr>
                    <?}?>
                </table>
                <?
                    $bookid = $_GET["bookid"];
                    if($bookid != "")
                    {
                        $str6 = "DELETE FROM `books` WHERE `id` =".$bookid;
                        $result6 = mysqli_query($link, $str6) or die("Не могу выполнить запрос212!");
                    }
                ?>
				
                
                
				<?
				
                include("dbinsert.php");
                $str9 = "SELECT * FROM avtor";
                $result9 = mysqli_query($link, $str9) or die("Не могу выполнить запрос1!");

                
				?>
                <h1><font color="black">Автор</font></h1><a href="avtor.php" type="button">Добавить автора</a>
                <table align="center" border="1">
                    <tr>
                        <td>#</td>
                        <td>Имя</td>
                        <td>Добавочное</td>
                        <td>Изменить</td>
                        <td>Удалить</td>
                    </tr>
                    <?
                        while($row=mysqli_fetch_array($result9))
                    {?>
                    <tr>
                        <td><?print $row["id"];?></td>
                        <td><?print $row["FIO"];?></td>
                        <td><?print $row["ost"];?></td>
                        <td><a href="updateavtor.php?&id=<?print $row["id"];?>">Изменить</a></td>
                        <td><a href="admin.php?&avtorid=<?print $row["id"];?>">Удалить</a></td>
                    </tr>
                    <?}?>
                </table>
                <?
                    $avtorid = $_GET["avtorid"];
                    if($avtorid != "")
                    {
                        $str10 = "DELETE FROM `avtor` WHERE `id` =".$avtorid;
                        $result10 = mysqli_query($link, $str10) or die("Не могу выполнить запрос2!");
                    }
                ?>
				
               
        </div>
    
    </section>
   
    

    <footer>

        
            
            <nav>
        
                <ul class="left">
    
                    <li>
                    
                  
		</li>
                    
                    
                    
                </ul>
            
            </nav>
            
            <div class="clear">
            </div>
        
        </div>
    
    </footer>

    <!--
    facebook SDK
    -->
    <div id="fb-root"></div>
    <script>(function(d, s, id) {
      var js, fjs = d.getElementsByTagName(s)[0];
      if (d.getElementById(id)) return;
      js = d.createElement(s); js.id = id;
      js.src = "http://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.0";
      fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));</script>

    <script src="_assets/_libs/jquery.js"></script>
    <script src="http://maps.google.com/maps/api/js?sensor=false"></script>
    <script src="_assets/_libs/no-ui-slider/jquery.nouislider.all.min.js"></script>
    <script src="_assets/_libs/smoothscroll.js"></script>
    <script src="_assets/_libs/parallax.js"></script>
    <script src="_assets/_js/functions.js"></script>
	

</body>
</html>